/**
 * 
 */
/**
 * 
 */
module java103 {
	requires java.desktop;
}